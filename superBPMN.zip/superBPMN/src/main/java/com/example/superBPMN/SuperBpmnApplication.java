package com.example.superBPMN;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SuperBpmnApplication {

	public static void main(String[] args) {
		SpringApplication.run(SuperBpmnApplication.class, args);
	}
}
